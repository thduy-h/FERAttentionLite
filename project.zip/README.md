# Facial Emotion Recognition — model adapter template

This is a Windows-friendly local inference pipeline for images, video files, webcams and HTTP IP cameras. It detects multiple faces, displays each prediction and confidence, and shows full-pipeline FPS. The **Git-tracked project contains no trained model, model architecture, model-specific preprocessing or checkpoint**. Add your own predictor before running inference.

## Windows setup (PowerShell)

Install Python 3.11 (64-bit), then run from this repository's root:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m src.app --help
```

On Windows, install the dependencies with pip. For a CPU-only PyTorch wheel, follow the current Windows/Pip/CPU command on the [official PyTorch selector](https://pytorch.org/get-started/locally/) before installing the rest of `requirements.txt`. The [OpenCV Python package](https://github.com/opencv/opencv-python) includes the Haar cascade used by this project. `opencv-python` stays below version 5 because this code expects `cv2.data.haarcascades`.

## Add your model

1. Put your architecture in `src/models/friend_model.py` and your checkpoint in `weights/friend.pt`.
2. Create `src/predictors/friend_model.py` with `FriendModelPredictor(BaseEmotionPredictor)`. Implement `model_name()` and `predict(face_bgr) -> PredictionResult`. The predictor owns checkpoint loading, BGR-to-model preprocessing, device selection, inference and **its own class order**. The crop passed by the app is BGR; do not assume it matches the model input directly.
3. In `src/predictors/factory.py`, replace the `NotImplementedError` for `friend` with an import and return of `FriendModelPredictor(weights_path=weights_path, device=device)`.
4. Adjust `model.friend_weights` in `config.yaml` if your checkpoint has another name. If you register a different model key, also change `model.active` and add `<key>_weights`.

The shared result format is `PredictionResult(label, confidence, probabilities)`. The app, detector, drawing and video/camera loops do not need model-specific changes. The factory intentionally raises `NotImplementedError` until your predictor is registered; it does not invent weights or labels.

## Run after registering the predictor

```powershell
# Image: saves outputs/<name>_result.jpg
.\.venv\Scripts\python.exe -m src.app --source test.jpg

# Video: press q or ESC to stop
.\.venv\Scripts\python.exe -m src.app --source test.mp4 --save-output outputs\result.mp4

# Webcam: try 0, 1, 2 until the correct camera opens
.\.venv\Scripts\python.exe -m src.app --source 0

# IP camera: use the current phone IP and the stream URL supplied by its app
.\.venv\Scripts\python.exe -m src.app --source http://192.168.1.15:4747/video

# Per-face predictor timing on CPU
.\.venv\Scripts\python.exe -m src.benchmark --model friend --weights weights\friend.pt
```

You can set `camera.source` in `config.yaml` to a webcam index or URL to omit `--source`. CLI flags override config. A private `config.local.yaml`, when present, is used as the default config instead and is ignored by Git. Pass `--config config.yaml` to use the public defaults explicitly. `--device cpu` is the default; `--device auto` and `--device cuda` are passed to the predictor. An HTTP camera URL must be updated if the phone IP changes. `q` or `ESC` closes the display window. Use `--no-display` for image/video batch runs without a GUI.

## Safe GitHub sharing

Create the Git repository in **this project root**. Its `.gitignore` excludes checkpoints, outputs, local environments, private config/notes, and model implementation files by default. `src/predictors/local_registry.py` is also local-only; the public factory works without it. Before committing, run `git status --short` and `git ls-files` to verify that no private files were staged or already tracked. `.gitignore` does not remove files that Git already tracks.

```powershell
git init
git add .
git status --short
git commit -m "Share model-agnostic inference pipeline"
```

The owner can share this template; the recipient then adds their own model and predictor locally. If the recipient later wants to publish their model code, they must explicitly change `.gitignore` and review the staged files.

## Troubleshooting

- **`FriendModelPredictor` not implemented:** add the predictor and register it in the factory as described above.
- **Checkpoint missing or mismatch:** check the path and that the architecture exactly matches the checkpoint. Do not edit layer names to force a load.
- **No face detected:** use a well-lit frontal face; lower `--min-face` or `detector.min_neighbors` if needed.
- **Camera cannot open:** try another webcam index and close other camera apps.
- **IP camera disconnected:** confirm the phone IP, port, Wi-Fi and stream URL; the app retries after a disconnect.
- **Low FPS:** try `--detector-scale 0.5`, `--skip-frames 1` or lower camera resolution.
- **Wrong label:** check the predictor's own label order and preprocessing. The app does not know either.
- **Windows `cv2` DLL load error:** install the current Microsoft Visual C++ Redistributable, as noted by the [OpenCV Python project](https://github.com/opencv/opencv-python).
