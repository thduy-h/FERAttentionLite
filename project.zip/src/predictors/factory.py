"""Register model-specific predictors here without changing the app."""

from __future__ import annotations

from pathlib import Path
from typing import Union

from src.predictors.base import BaseEmotionPredictor

try:
    from src.predictors.local_registry import LOCAL_MODELS, create_local_predictor
except ModuleNotFoundError as exc:
    if exc.name != "src.predictors.local_registry":
        raise
    LOCAL_MODELS = ()

AVAILABLE_MODELS = ("friend",) + tuple(LOCAL_MODELS)


def create_predictor(
    model_name: str,
    weights_path: Union[str, Path],
    device: str = "cpu",
) -> BaseEmotionPredictor:
    name = (model_name or "").lower().strip()
    if name == "friend":
        # After adding src/predictors/friend_model.py, replace this line with:
        # from src.predictors.friend_model import FriendModelPredictor
        # return FriendModelPredictor(weights_path=weights_path, device=device)
        raise NotImplementedError(
            "Add FriendModelPredictor in src/predictors/friend_model.py "
            "and register it in src/predictors/factory.py."
        )
    if name in LOCAL_MODELS:
        return create_local_predictor(name, weights_path, device)
    raise ValueError(
        f"Unknown model '{model_name}'. Available: {', '.join(AVAILABLE_MODELS)}"
    )
